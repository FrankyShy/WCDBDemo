//
//  DBManager.h
//  WCDBDemo
//
//  Created by SunHaoyu on 2018/11/9.
//  Copyright © 2018年 Shy. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DBManager : NSObject

+ (void)createDatabase;

@end

NS_ASSUME_NONNULL_END
