//
//  DBManager.m
//  WCDBDemo
//
//  Created by SunHaoyu on 2018/11/9.
//  Copyright © 2018年 Shy. All rights reserved.
//

#import "DBManager.h"
#import <FMDB/FMDB.h>
#import <WCDB/WCDB.h>

@implementation DBManager

+ (void)createDatabase{
    NSString *docuPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *dbPath = [docuPath stringByAppendingPathComponent:@"student.db"];
    NSLog(@"!!!dbPath = %@",dbPath);
    FMDatabase *db = [FMDatabase databaseWithPath:dbPath];

    [db open];
    if (![db open]) {
        NSLog(@"db open fail");
        return;
    }
    NSString *sql = @"create table if not exists t_student ('ID' INTEGER PRIMARY KEY AUTOINCREMENT,'name' TEXT NOT NULL, 'phone' TEXT NOT NULL,'score' INTEGER NOT NULL)";
    BOOL result = [db executeUpdate:sql];
    if (result) {
        NSLog(@"create table success");
    }
    [db close];
}



@end
