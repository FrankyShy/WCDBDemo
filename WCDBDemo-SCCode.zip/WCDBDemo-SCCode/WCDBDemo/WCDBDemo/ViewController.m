//
//  ViewController.m
//  WCDBDemo
//
//  Created by SunHaoyu on 2018/11/12.
//  Copyright © 2018年 Shy. All rights reserved.
//

#import "ViewController.h"
#import "DBManager.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIButton *btn = [UIButton new];
    btn.frame = CGRectMake(100, 100, 300, 100);
    btn.backgroundColor = [UIColor redColor];
    [btn setTitle:@"点击创建数据库" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(create) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}

- (void)create {
    [DBManager createDatabase];
}


@end
